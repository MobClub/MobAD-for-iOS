//
//  MADKSConnector.h
//  MKADConnector
//
//  Created by Sands_Lee on 2019/11/19.
//  Copyright © 2019 Sands_Lee. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MADKSConnector : NSObject

@end

