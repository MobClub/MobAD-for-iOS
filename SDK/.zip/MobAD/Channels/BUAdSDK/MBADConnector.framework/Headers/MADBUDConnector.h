//
//  MADBUDConnector.h
//  MBADConnector
//
//  Created by Sands_Lee on 2019/11/1.
//  Copyright © 2019 Sands_Lee. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MADBUDConnector : NSObject

@end

