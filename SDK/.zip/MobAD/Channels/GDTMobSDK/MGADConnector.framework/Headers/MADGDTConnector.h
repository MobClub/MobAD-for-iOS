//
//  MADGDTConnector.h
//  MGADConnector
//
//  Created by Sands_Lee on 2019/10/31.
//  Copyright © 2019 Sands_Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MADGDTConnector : NSObject

@end

